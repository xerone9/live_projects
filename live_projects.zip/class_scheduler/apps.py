from django.apps import AppConfig


class ClassSchedulerConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'class_scheduler'
